import users from './users'
import user from './user'

export default {
  user,
  users
}
